
# Libraries
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error

#0. Load Data
import pandas as pd
bikes = pd.read_csv('bikes.csv')
features= ['temperature', 'humidity', 'windspeed']

X = bikes[features]
y = bikes['count']

# 0.1 Split the data training and test 
# sample a training set while holding out 40% of the data for testing (evaluating) our classifier:
from sklearn.model_selection import train_test_split
rng = np.random.RandomState(1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, 
                                                    random_state = rng)



# Fit regression model
regressors = []
regressors.append(DecisionTreeRegressor(max_depth=4, criterion='mae'))
# http://scikit-learn.org/stable/auto_examples/ensemble/plot_adaboost_regression.html#
regressors.append(AdaBoostRegressor(DecisionTreeRegressor(max_depth=4, criterion='mae'),
                          n_estimators=300, random_state=rng))
#http://scikit-learn.org/stable/auto_examples/ensemble/plot_gradient_boosting_regression.html#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regression-py                         
regressors.append(GradientBoostingRegressor(n_estimators=100, learning_rate=0.1,
                                   max_depth=4, random_state=0, loss='ls'))                

xx = np.stack(i for i in range(len(y_test)))
regr_names = ["DT", "AB", "GB"]
               
for i, r in enumerate(regressors):
    r.fit(X_train, y_train)
    y = r.predict(X_test)
    print "Error Measure", mean_absolute_error(y_test,y)
    # Plot the results
    plt.figure()
    plt.scatter(xx, y_test, c="k", label="training samples")
    plt.plot(xx, y, c="g", label=regr_names[i], linewidth=2)
    plt.xlabel("data")
    plt.ylabel("target")
    plt.title(regr_names[i])
    plt.axis('tight')
    plt.legend()
    plt.show()


# FEATURE RELEVANCIES
print ('Feature Relevancies')
pd.DataFrame({'Attributes': features ,       
              'DT':regressors[0].feature_importances_,
              'Boosting:AB':regressors[1].feature_importances_,
              'Boosting:GB':regressors[2].feature_importances_})
pd

