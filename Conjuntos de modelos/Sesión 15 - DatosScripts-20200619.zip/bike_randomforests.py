# -*- coding: utf-8 -*-
"""
Created on Tue Nov 14 10:44:10 2017

@author: FranciscoP.Romero
"""

# 0. load data
import pandas as pd
import matplotlib.pyplot as plt
bikes = pd.read_csv('bikes.csv')
bikes.head()

# preprocessing.
features= ('temperature', 'humidity', 'windspeed')

X = bikes[['temperature', 'humidity','windspeed']]
y = bikes['count']

# sample a training set while holding out 40% of the data for testing (evaluating) our classifier:
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4)

# 2.2 Feature Relevances

from sklearn.ensemble import RandomForestRegressor

#1.1 Model Parametrization 
regressor = RandomForestRegressor(n_estimators= 4, max_depth = 2, criterion='mae', random_state=0)
#1.2 Model construction
regressor.fit(X_train, y_train)

# Test
y_pred = regressor.predict(X_test)

# metrics calculation 
from sklearn.metrics import mean_absolute_error
mae = mean_absolute_error(y_test,y_pred)
print "Error Measure ", mae



#plt.subplot(2, 1, i + 1)
# x axis for plotting
import numpy as np
xx = np.stack(i for i in range(len(y_test)))
plt.scatter(xx, y_test, c='r', label='data')
plt.plot(xx, y_pred, c='g', label='prediction')
plt.axis('tight')
plt.legend()
plt.title("Random Forests")

plt.show()

# FEATURE RELEVANCIES
print ('Feature Relevances')
pd.DataFrame({'Attributes': features ,       
              'Random Forests':regressor.feature_importances_})
    
    

